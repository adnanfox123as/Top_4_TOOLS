# ***Just use http://ip8.com***
#

<p align="center">
<a href="#"><img title="Host" src="https://raw.githubusercontent.com/htr-tech/release-download/master/images/banner/trackip.png"></a>
</p>
<p align="center">
<a href="https://github.com/htr-tech"><img title="Author" src="https://img.shields.io/badge/Author-htr--tech-red.svg?style=for-the-badge&logo=github"></a>
<a href="#"><img title="Open Source" src="https://img.shields.io/badge/Open%20Source-%E2%9D%A4-green?style=for-the-badge"></a>
</p>
<p align="center">
<a href="#"><img title="Version" src="https://img.shields.io/badge/Version-2.0-green.svg?style=flat-square"></a>
<a href="#"><img title="Language" src="https://badges.frapsoft.com/bash/v1/bash.png?v=103"></a>
<a href="https://github.com/htr-tech/followers"><img title="Followers" src="https://img.shields.io/github/followers/htr-tech?color=blue&style=flat-square"></a>
<a href="https://github.com/htr-tech/track-ip/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/htr-tech/track-ip?color=red&style=flat-square"></a>
<a href="https://github.com/htr-tech/track-ip/network/members"><img title="Forks" src="https://img.shields.io/github/forks/htr-tech/track-ip?color=red&style=flat-square"></a>
<a href="https://github.com/htr-tech/track-ip/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/htr-tech/track-ip?label=Watchers&color=blue&style=flat-square"></a>
</p>

## Installation :

* `apt update`
* `apt install git curl -y`
* `git clone git://github.com/htr-tech/track-ip.git`
* `cd track-ip`

#### > Run : `bash trackip`

## Single Command :
```
apt update ; apt install git curl -y ; git clone git://github.com/htr-tech/track-ip.git ; cd track-ip ; bash trackip
```
<br>
<p align="center">
<img src="https://raw.githubusercontent.com/htr-tech/release-download/master/images/trackip.png"/>

### <<< If you copy , Then Give me The Credits >>>

## Find Me on :
[![Github](https://img.shields.io/badge/Github-HTR--TECH-green?style=for-the-badge&logo=github)](https://github.com/htr-tech)
[![Instagram](https://img.shields.io/badge/IG-%40tahmid.rayat-red?style=for-the-badge&logo=instagram)](https://www.instagram.com/tahmid.rayat)
[![Messenger](https://img.shields.io/badge/Chat-Messenger-blue?style=for-the-badge&logo=messenger)](https://m.me/tahmid.rayat.official)
